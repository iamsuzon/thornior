<div class="top-navbar">
    <div class="container-fluid p-0">
        <div class="nav-item">
            <div class="left-menu">
                <div class="nav-toggle me-3" onclick="menuAnimation(this)">
                    <i class="fa fa-times"></i>
                </div>
                <ul class="left-menulist">
                    <li class="active">
                        <a href="#0">Blog</a>
                    </li>
                    <li>
                        <a href="#0">Explore</a>
                    </li>
                </ul>
            </div>
            <div class="menu-item">
                <ul class="item-list" id="topList">
                    <li><a href="#"><span><i class="fa fa-bell"></i></span></a></li>
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false">
                            <span><img src="assets/images/blogger/user.png" height="35" width="35" alt=""></span>
                            <span class="ml-1">Natasa</span>
                        </a>
                        <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
                            <li><a class="dropdown-item" href="@auth('admin') {{route('admin.settings.profile.index')}} @else {{route('blogger.profile')}} @endauth">Profile</a></li>
                            <li><a class="dropdown-item" href="@auth('admin') {{route('admin.logout')}} @else {{route('blogger.logout')}} @endauth">Logout</a></li>
                            {{--                            <li><a class="dropdown-item" href="#">Something else here</a></li>--}}
                        </ul>
                    </li>
                </ul>
                <div class="top-toggle d-block d-sm-none" onclick="topNav(this)">
                    <i class="fa fa-ellipsis-v"></i>
                </div>
            </div>
        </div>
    </div>
</div>
