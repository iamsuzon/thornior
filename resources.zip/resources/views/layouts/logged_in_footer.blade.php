<footer>
    <div class="footer-content">
        <p>&copy; 2021 | Thornior | All right reserved</p>
        <p>V 1.8</p>
    </div>
</footer>
