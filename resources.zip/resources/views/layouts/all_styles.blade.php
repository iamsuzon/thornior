<!-- google fonts -->
<link href="https://fonts.googleapis.com/css2?family=Signika:wght@300;400;500;600;700&display=swap"
      rel="stylesheet">
<!-- font-awsome -->
<link rel="stylesheet" href="{{asset('backend/assets/css/all.min.css')}}">
<!-- bootstrap css -->
<link rel="stylesheet" href="{{asset('backend/assets/css/bootstrap.min.css')}}">
<!-- swiper css -->
<link rel="stylesheet" href="{{asset('backend/assets/css/swiper.min.css')}}">
<!-- animate css -->
<link rel="stylesheet" href="{{asset('backend/assets/css/animate.css')}}">
<!-- ui css -->
<link rel="stylesheet" href="{{asset('backend/assets/css/jquery-ui.css')}}">
<!-- lightcase css -->
<link rel="stylesheet" href="{{asset('backend/assets/css/lightcase.css')}}">
<!-- toastr css -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css">
<!-- ckeditor css -->
<link rel="stylesheet" href="{{asset('ckeditor5/build/ckeditor.css')}}">
<!-- style css -->
<link rel="stylesheet" href="{{asset('backend/assets/sass/style.css')}}">
