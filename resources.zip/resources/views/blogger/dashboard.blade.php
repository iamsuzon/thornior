@extends('layouts.blogger_loggedin_app')

@section('content')
    <!-- page header start -->
    <section class="blogger-page-header">
        <div class="header-content">
            <span>@if(isset(Auth::user()->blog->region)) {{Auth::user()->blog->country->name}} @endif</span>
            <h3>{{Auth::user()->blog->blog_name}}</h3>
            <span class="update">{{Auth::user()->blog->updated_at->format('i M Y')}}</span>
{{--            <button type="button" class="btn"><span>Create Mode</span></button>--}}
        </div>
    </section>
    <!-- page header ends  -->

    <!-- girid layout -->
    <div class="row grid-row">
        <div class="col-lg-9 col-12">
            <!-- setup blog start -->
            <section class="setup-blog">
                <div class="section-header">
                    <span>New</span>
                    <h3>Set Up Your Blog</h3>
                    <!-- slider arrow -->
                    <div class="slider-arrow">
{{--                        <div class="latest-button-prev prev">--}}
{{--                            <i class="fa fa-angle-left"></i>--}}
{{--                        </div>--}}
{{--                        <div class="latest-button-next next">--}}
{{--                            <i class="fa fa-angle-right"></i>--}}
{{--                        </div>--}}
                    </div>
                </div>
                <div class="section-wrapper">
                    <div class="setup-slider">
                        <div class="swiper-wrapper">
                            <a href="{{route('blogger.blog.post.templates')}}" class="swiper-slide">
                                <div class="setup-item">
                                    <div class="item-left">
                                        <i class="fas fa-images"></i>
                                    </div>
                                    <div class="item-right">
                                        <h5>Create Image Post</h5>
                                        <span>Create Image Post</span>
                                    </div>
                                </div>
                            </a>
                            <a href="#{{route('blogger.blog.post.video.index')}}" class="swiper-slide">
                                <div class="setup-item">
                                    <div class="item-left">
                                        <i class="fas fa-photo-video"></i>
                                    </div>
                                    <div class="item-right">
                                        <h5>Create Video Mode</h5>
                                        <span>Create Video Mode</span>
                                    </div>
                                </div>
                            </a>
                            <a href="{{route('blogger.blog.product.index')}}" class="swiper-slide">
                                <div class="setup-item">
                                    <div class="item-left">
                                        <i class="fas fa-ad"></i>
                                    </div>
                                    <div class="item-right">
                                        <h5>Create Product Mode</h5>
                                        <span>Create Product Mode</span>
                                    </div>
                                </div>
                            </a>
                        </div>
                    </div>
                </div>
            </section>
            <!-- setup blog ends  -->

            <!-- blog library start -->
            <section class="blog-libarary">
                <div class="section-header">
                    <h3>Library</h3>
                </div>
                <div class="section-wrapper">
                    <div id="tabs">
                        <ul class="mb-4">
                            <li><a href="#tabs-1">Overview</a></li>
                            <li><a href="#tabs-2">Post</a></li>
                            <li><a href="#tabs-3">Category</a></li>
                            <li><a href="#tabs-4">Videos</a></li>
                        </ul>
                        <div id="tabs-1" class="bloger-tabs">
                            <div class="row">
                                @forelse($posts['image_one'] as $post)
                                    <div class="col-lg-4 col-md-6 col-sm-6 col-12 mt-4 mt-sm-0">
                                        <div class="blog-item">
                                            <div class="item-thumb">
                                                <img src="{{asset('upload/blogger_image_post')}}/{{$post->fimage}}" alt="">
                                            </div>
                                            <div class="item-content">
                                                <div class="cato-content">
                                                    <span class="cat-btn text-capitalize">@foreach($post->categories as $category) {{$category->name}} @if($post->categories->count() > 1)+{{$post->categories->count()-1}} more @break @endif  @endforeach</span>
                                                    <span><i class="fas fa-ellipsis-h"></i></span>
                                                </div>
                                                <p>{{substr($post->title,0,60)}}{{((strlen($post->title)) > 60) ? '...' : ''}}</p>
                                            </div>
                                            <div class="hover-content">
                                                <a href="{{route('blogger.blog.post.image.show',$post->slug)}}" type="button" class="bg-white"><span>Show</span></a>
                                                <a href="{{route('blogger.blog.post.image.edit.1',$post->id)}}" type="button" class="btn"><span>Edit</span></a>
                                            </div>
                                        </div>
                                    </div>
                                @empty
                                    <p class="text-center">No Post Available</p>
                                @endforelse
                            </div>
                        </div>
                        <div id="tabs-2">
                            <p>Morbi tincidunt, dui sit amet facilisis feugiat, odio metus gravida ante, ut pharetra massa metus id nunc. Duis scelerisque molestie turpis. Sed fringilla, massa eget luctus malesuada, metus eros molestie lectus, ut tempus eros massa ut dolor. Aenean aliquet fringilla sem. Suspendisse sed ligula in ligula suscipit aliquam. Praesent in eros vestibulum mi adipiscing adipiscing. Morbi facilisis. Curabitur ornare consequat nunc. Aenean vel metus. Ut posuere viverra nulla. Aliquam erat volutpat. Pellentesque convallis. Maecenas feugiat, tellus pellentesque pretium posuere, felis lorem euismod felis, eu ornare leo nisi vel felis. Mauris consectetur tortor et purus.</p>
                        </div>
                        <div id="tabs-3">
                            <p>Mauris eleifend est et turpis. Duis id erat. Suspendisse potenti. Aliquam vulputate, pede vel vehicula accumsan, mi neque rutrum erat, eu congue orci lorem eget lorem. Vestibulum non ante. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Fusce sodales. Quisque eu urna vel enim commodo pellentesque. Praesent eu risus hendrerit ligula tempus pretium. Curabitur lorem enim, pretium nec, feugiat nec, luctus a, lacus.</p>
                            <p>Duis cursus. Maecenas ligula eros, blandit nec, pharetra at, semper at, magna. Nullam ac lacus. Nulla facilisi. Praesent viverra justo vitae neque. Praesent blandit adipiscing velit. Suspendisse potenti. Donec mattis, pede vel pharetra blandit, magna ligula faucibus eros, id euismod lacus dolor eget odio. Nam scelerisque. Donec non libero sed nulla mattis commodo. Ut sagittis. Donec nisi lectus, feugiat porttitor, tempor ac, tempor vitae, pede. Aenean vehicula velit eu tellus interdum rutrum. Maecenas commodo. Pellentesque nec elit. Fusce in lacus. Vivamus a libero vitae lectus hendrerit hendrerit.</p>
                        </div>
                        <div id="tabs-4">
                            <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Tempore autem culpa sequi corporis ipsa iure provident aliquam accusamus amet ad tenetur temporibus quibusdam velit fugiat ratione laudantium consequatur fuga non omnis eius repellat quo, perspiciatis optio numquam! Tempora, maxime fugit.</p>
                            <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Tempore autem culpa sequi corporis ipsa iure provident aliquam accusamus amet ad tenetur temporibus quibusdam velit fugiat ratione laudantium consequatur fuga non omnis eius repellat quo, perspiciatis optio numquam! Tempora, maxime fugit.</p>
                        </div>
                    </div>
                </div>
            </section>
            <!-- blog library ends  -->
        </div>
        <div class="col-lg-3 col-md-7 col-sm-8 col-12">
            <div class="blog-wizard">
                <div class="wizard-title">
                    <h4>Commets</h4>
                    <a href="#0">See All</a>
                </div>
                <div class="wizard-body">
                    <div class="blog-item border-bottom">
                        <div class="blog-thumb">
                            <img src="assets/images/blog/latest/02.jpg" alt="">
                        </div>
                        <div class="blog-text">
                            <h5>Look into the exclusive dream house in the ...</h5>
                        </div>
                        <div class="blog-timeline">
                            <div class="time-line">
                                <span class="border-end pe-2">Mona Luna Litland</span>
                                <span>5 Days ago</span>
                            </div>
                        </div>
                    </div>
                    <div class="comments-reply">
                        <ul class="reply-list">
                            <li>
                                <div class="repl-thumb">
                                    <img src="assets/images/blog/latest/01.png" alt="">
                                </div>
                                <div class="repl-text">
                                    <h6>Logan</h6>
                                    <p>Lorem ipsum dolor sit amet.</p>
                                    <span><i class="fa fa-comment-alt"></i></span><span>Reply</span>
                                </div>
                            </li>
                            <li>
                                <div class="repl-thumb">
                                    <img src="assets/images/blog/latest/01.png" alt="">
                                </div>
                                <div class="repl-text">
                                    <h6>Jsica</h6>
                                    <p>Lorem ipsum dolor sit amet.</p>
                                    <span><i class="fa fa-comment-alt"></i></span><span>Reply</span>
                                </div>
                            </li>
                            <li>
                                <div class="repl-thumb">
                                    <img src="assets/images/blog/latest/01.png" alt="">
                                </div>
                                <div class="repl-text">
                                    <h6>Morgan</h6>
                                    <p>Lorem ipsum dolor sit amet.</p>
                                    <span><i class="fa fa-comment-alt"></i></span><span>Reply</span>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="wizard-title mt-4">
                    <h4>Latest Post</h4>
                    <a href="#0">See All</a>
                </div>
                <div class="wizard-body">
                    <ul class="blog-item">
                        <li>
                            <div class="blog-thumb">
                                <img src="assets/images/blog/latest/01.jpg" alt="">
                            </div>
                            <div class="blog-text">
                                <h6>Look in to the exclusive dream house...</h6>
                                <div class="blog-timeline">
                                    <div class="time-line">
                                        <span class="border-end pe-2">Mona Luna Litland</span>
                                        <span>5 Days ago</span>
                                    </div>
                                </div>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!-- girid layout -->
@endsection
