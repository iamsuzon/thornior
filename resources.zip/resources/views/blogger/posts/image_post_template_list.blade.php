@extends('layouts.blogger_loggedin_app')

@section('content')
    <section class="mt-5">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <h3 class="text-center"> Get Inspiration</h3>
                    <h4 class="text-center" style="color: darkgrey">See templates from all kinds of blog posts that fits your needs</h4>
                </div>
            </div>
        </div>
    </section>

    <!-- common blog area start -->
    <section class="blog-area my-5">
        <div class="container-fluid">
            <div class="section-wrapper">
                <div class="row justify-content-center gx-5">
                    <div class="col-lg-6 col-md-6 col-6">
                        <div class="blog-wrapper">
                            <div class="row mb-3">
                                <div class="col-12">
                                    <h4 class="d-inline-block">For Image Post</h4>
                                    <a class="d-inline-block float-end btn btn-dark text-dark" style="background-color: lightgrey" href="">See All</a>
                                </div>
                            </div>
                            <div class="row gx-3">
                                <div class="col-md-4 col-sm-6 col-12">
                                    <a href="{{route('blogger.blog.post.image.index.1')}}">
                                        <div class="blog-item">
                                            <div class="item-thumb">
                                                <img src="{{asset('backend/assets/images/blog/latest/01.jpg')}}" class="rounded" alt="">
                                            </div>
                                            <div class="blog-text mt-2 text-center">
                                                <h5>Template 1</h5>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                                <div class="col-md-4 col-sm-6 col-12 mt-4 mt-sm-0">
                                    <a href="">
                                        <div class="blog-item">
                                            <div class="item-thumb">
                                                <img src="{{asset('backend/assets/images/blog/latest/01.jpg')}}" class="rounded" alt="">
                                            </div>
                                            <div class="blog-text mt-2 text-center">
                                                <h5>Template 2</h5>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                                <div class="col-md-4 col-sm-6 col-12 mt-4 mt-md-0">
                                    <a href="">
                                        <div class="blog-item">
                                            <div class="item-thumb">
                                                <img src="{{asset('backend/assets/images/blog/latest/01.jpg')}}" class="rounded" alt="">
                                            </div>
                                            <div class="blog-text mt-2 text-center">
                                                <h5>Template 3</h5>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                            </div>
                            <div class="row mt-5 gx-3">
                                <div class="col-md-4 col-sm-6 col-12">
                                    <a href="">
                                        <div class="blog-item">
                                            <div class="item-thumb">
                                                <img src="{{asset('backend/assets/images/blog/latest/01.jpg')}}" class="rounded" alt="">
                                            </div>
                                            <div class="blog-text mt-2 text-center">
                                                <h5>Template 4</h5>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                                <div class="col-md-4 col-sm-6 col-12 mt-4 mt-sm-0">
                                    <a href="">
                                        <div class="blog-item">
                                            <div class="item-thumb">
                                                <img src="{{asset('backend/assets/images/blog/latest/01.jpg')}}" class="rounded" alt="">
                                            </div>
                                            <div class="blog-text mt-2 text-center">
                                                <h5>Template 5</h5>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                                <div class="col-md-4 col-sm-6 col-12 mt-4 mt-md-0">
                                    <a href="">
                                        <div class="blog-item">
                                            <div class="item-thumb">
                                                <img src="{{asset('backend/assets/images/blog/latest/01.jpg')}}" class="rounded" alt="">
                                            </div>
                                            <div class="blog-text mt-2 text-center">
                                                <h5>Template 6</h5>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-6">
                        <div class="blog-wrapper">
                            <div class="row mb-3">
                                <div class="col-12">
                                    <h4 class="d-inline-block">For Video Post</h4>
                                    <a class="d-inline-block float-end btn btn-dark text-dark" style="background-color: lightgrey" href="">See All</a>
                                </div>
                            </div>
                            <div class="row gx-3">
                                <div class="col-md-4 col-sm-6 col-12">
                                    <a href="">
                                        <div class="blog-item">
                                            <div class="item-thumb">
                                                <img src="{{asset('backend/assets/images/blog/latest/01.jpg')}}" class="rounded" alt="">
                                            </div>
                                            <div class="blog-text mt-2 text-center">
                                                <h5>Template 1</h5>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                                <div class="col-md-4 col-sm-6 col-12 mt-4 mt-sm-0">
                                    <a href="">
                                        <div class="blog-item">
                                            <div class="item-thumb">
                                                <img src="{{asset('backend/assets/images/blog/latest/01.jpg')}}" class="rounded" alt="">
                                            </div>
                                            <div class="blog-text mt-2 text-center">
                                                <h5>Template 2</h5>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                                <div class="col-md-4 col-sm-6 col-12 mt-4 mt-md-0">
                                    <a href="">
                                        <div class="blog-item">
                                            <div class="item-thumb">
                                                <img src="{{asset('backend/assets/images/blog/latest/01.jpg')}}" class="rounded" alt="">
                                            </div>
                                            <div class="blog-text mt-2 text-center">
                                                <h5>Template 3</h5>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                            </div>
                            <div class="row mt-5 gx-3">
                                <div class="col-md-4 col-sm-6 col-12">
                                    <a href="">
                                        <div class="blog-item">
                                            <div class="item-thumb">
                                                <img src="{{asset('backend/assets/images/blog/latest/01.jpg')}}" class="rounded" alt="">
                                            </div>
                                            <div class="blog-text mt-2 text-center">
                                                <h5>Template 4</h5>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                                <div class="col-md-4 col-sm-6 col-12 mt-4 mt-sm-0">
                                    <a href="">
                                        <div class="blog-item">
                                            <div class="item-thumb">
                                                <img src="{{asset('backend/assets/images/blog/latest/01.jpg')}}" class="rounded" alt="">
                                            </div>
                                            <div class="blog-text mt-2 text-center">
                                                <h5>Template 5</h5>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                                <div class="col-md-4 col-sm-6 col-12 mt-4 mt-md-0">
                                    <a href="">
                                        <div class="blog-item">
                                            <div class="item-thumb">
                                                <img src="{{asset('backend/assets/images/blog/latest/01.jpg')}}" class="rounded" alt="">
                                            </div>
                                            <div class="blog-text mt-2 text-center">
                                                <h5>Template 6</h5>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- common blog area ends  -->
@endsection
