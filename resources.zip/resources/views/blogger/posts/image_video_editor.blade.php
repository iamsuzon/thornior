<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    @include('layouts.all_styles')

    <title>Thornior</title>
    <script src="{{asset('ckeditor5/build/ckeditor.js')}}"></script>
</head>
<body>
<style>
    .ck-editor__editable_inline {
        min-height: 1100px;
    }

    .word-count-card {
        padding: 10px 15px;
    }

    .word-count-card .ck-word-count__words {
        display: inline;
    }

    .word-count-card {
        padding: 0;
        border-radius: 0;
        border-top: 0;
    }

    .word-count-card-body .ck-word-count__characters {
        display: inline;
        margin-left: 10px;
    }

    .post-left-nav-button a:hover, .post-right-nav-button a:hover {
        background-color: #E2DED1;
    }
</style>

<div class="main-content">
    <!-- vertica sidebar start -->
    <div class="vertical-sidebar" id="slideNav">
        <div class="sidebar-content">
            <div class="brand-logo">
                <img src="{{asset('backend/assets/images/logo/01.png')}}" alt="">
                <span class="close-icon d-md-none float-end me-2" onclick="menuAnimation(this)">
                    <i class="fa fa-times"></i>
                </span>
            </div>
            <div class="seller-thumb">
                <div class="img-thumb">
                    <img src="{{asset('backend/assets/images/blogger/user.png')}}" alt="">
                </div>
                <div class="text-thumb">
                    <p>Natasa</p>
                    <span class="online-status">@natasa180</span>
                </div>
                <div class="post-status">
                    <ul class="status-list">
                        <li>
                            <strong>28</strong>
                            <p>Posts</p>
                        </li>
                        <li>
                            <strong>28</strong>
                            <p>Posts</p>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="sidebar-menu">
                <ul class="menu-list">
                    <div class="menu-title">
                        <p>Menu</p>
                    </div>
                    <li><a href="#0"><span><i class="fas fa-th-large"></i></span><span>Overview</span></a></li>
                    <li><a href="#0"><span><i class="fab fa-blogger-b"></i></span><span>Blog</span></a></li>
                    <li><a href="#0"><span><i class="fas fa-book-open"></i></span><span>Library</span></a></li>
                    <li class="accordion" id="accordionExample">
                        <a href="#0" class="headingOne" data-toggle="collapse" data-target="#collapseOne"
                           aria-expanded="false" aria-controls="collapseOne">
                            <span>
                                <i class="fas fa-hashtag"></i>
                            </span>
                            <span>Social Links</span>
                        </a>
                    </li>
                    <li><a href="#0"><span><i class="fas fa-cog"></i></span><span>Settings</span></a></li>
                    <div class="menu-title">
                        <p>Create</p>
                    </div>
                    <li><a class="active" href="#0"><span><i class="fas fa-paste"></i></span><span>Post</span></a></li>
                    <li><a href="#0"><span><i class="fas fa-list-ol"></i></span><span>Category</span></a></li>
                    <li><a href="#0"><span><i class="fas fa-gopuram"></i></span><span>Change Template</span></a></li>
                </ul>
            </div>

        </div>
    </div>
    <!-- vertica sidebar ends  -->


    <!-- content-right start -->
    <div class="content-right" id="contentWidth">

        <!-- top navbar start -->
    @include('layouts.logged_in_navbar')
    <!-- top navbar ends  -->

        <!-- post top navbar start -->
        <form action="{{route('blogger.blog.post.image.store')}}" method="POST"
              enctype="multipart/form-data" name="postForm" onsubmit="return validateForm()">
            @csrf
        <div class="top-navbar">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="post-left-nav-button d-inline-block float-start" style="margin-left: 20px">
                            <a class="btn p-3" href="#" style="background-color: #fff">Save in Library</a>
                            <div class="d-inline-block">
                                <select class="form-control" name="template" id="template">
                                    <option @if(old('template') == null) selected disabled @else disabled @endif>Select Template</option>
                                    <option value="1" @if(old('template') == 1 ) selected @endif>Template 1</option>
                                    <option value="2" @if(old('template') == 2) selected @endif>Template 2</option>
                                    <option value="3" @if(old('template') == 3) selected @endif>Template 3</option>
                                    <option value="4" @if(old('template') == 4) selected @endif>Template 4</option>
                                    <option value="5" @if(old('template') == 5) selected @endif>Template 5</option>
                                    <option value="6" @if(old('template') == 6) selected @endif>Template 6</option>
                                </select>
                            </div>
                        </div>
                        <div class="post-right-nav-button d-inline-block float-end" style="margin-right: 20px">
                            <a class="btn p-3" href="#" style="background-color: #fff">Preview</a>
                            <button type="submit" class="btn p-3" style="margin-left: 10px;background-color: #fff">Publish</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- post top navbar ends  -->

        <!-- Edit area start -->
        <div class="edit-area">
            <div class="container-fluid mt-5">
                <div class="row">
                    <div class="col-12">
                        <h4>Add New Post</h4>
                        @if ($errors->any())
                            <div class="alert alert-danger">
                                <ul>
                                    @foreach ($errors->all() as $error)
                                        <li>{{ $error }}</li>
                                    @endforeach
                                </ul>
                            </div>
                        @endif
{{--                        @if (session('success'))--}}
{{--                            <div class="alert alert-success">--}}
{{--                                {{session('success')}}--}}
{{--                            </div>--}}
{{--                        @endif--}}
                    </div>
                </div>

                    <div class="row">
                        <div class="col-lg-9 col-md-9 col-sm-12">
                            <div class="row">
                                <div class="col-12">
                                    <textarea name="editor" id="editor" rows="30">{!! old('editor') !!}</textarea>
                                    <div class="card word-count-card">
                                        <div class="card-body word-count-card-body">
                                            <div id="word-count"></div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="card mt-4">
                                <div class="card-header bg-white">Set Three Images* <span style="font-size: 10px">(Use same size images for better experience)</span>
                                </div>
                                <div class="card-body">
                                    <div class="row mt-2">
                                        <div class="col-4">
                                            <div class="post-image">
                                                <p><input type="file" accept="image/*" name="image1" id="file1"
                                                          onchange="loadImage1(event)" style="display: none;"></p>
                                                <p class="text-center" id="image-label1"><label for="file1"
                                                                                                style="cursor: pointer;"><i
                                                            class="fas fa-camera"></i> Set Image</label></p>
                                                <p id="image-box1" class="text-center"><img
                                                        src="{{asset('backend/assets/images/blog/placeholder.jpg')}}"
                                                        id="output1" width="200"/>
                                                </p>
                                                <p id="remove-image1" onclick="removeImage1(event)"
                                                   style="display: none; cursor: pointer;text-align: center">Remove
                                                    first image</p>
                                            </div>
                                        </div>
                                        <div class="col-4">
                                            <div class="post-image">
                                                <p><input type="file" accept="image/*" name="image2" id="file2"
                                                          onchange="loadImage2(event)" style="display: none;"></p>
                                                <p class="text-center" id="image-label2"><label for="file2"
                                                                                                style="cursor: pointer;"><i
                                                            class="fas fa-camera"></i> Set Image</label></p>
                                                <p id="image-box2" class="text-center"><img
                                                        src="{{asset('backend/assets/images/blog/placeholder.jpg')}}"
                                                        id="output2" width="200"/>
                                                </p>
                                                <p id="remove-image2" onclick="removeImage2(event)"
                                                   style="display: none; cursor: pointer;text-align: center">Remove
                                                    second image</p>
                                            </div>
                                        </div>
                                        <div class="col-4">
                                            <div class="post-image">
                                                <p><input type="file" accept="image/*" name="image3" id="file3"
                                                          onchange="loadImage3(event)" style="display: none;"></p>
                                                <p class="text-center" id="image-label3"><label for="file3"
                                                                                                style="cursor: pointer;"><i
                                                            class="fas fa-camera"></i> Set Image</label></p>
                                                <p id="image-box3" class="text-center"><img
                                                        src="{{asset('backend/assets/images/blog/placeholder.jpg')}}"
                                                        id="output3" width="200"/>
                                                </p>
                                                <p id="remove-image3" onclick="removeImage3(event)"
                                                   style="display: none;cursor: pointer;text-align: center">Remove third
                                                    image</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-3 col-md-3 col-sm-12">
                            <div class="card">
                                <div class="card-header bg-white">Featured Image</div>
                                <div class="card-body">
                                    <div class="post-image">
                                        <p><input type="file" accept="image/*" name="featured_image" id="file"
                                                  onchange="featuredImage(event)" style="display: none;"></p>
                                        <p id="image-label" class="text-center"><label for="file"
                                                                                       style="cursor: pointer;"><i
                                                    class="fas fa-camera"></i> Set featured
                                                image</label></p>
                                        <p id="image-box" class="text-center"><img
                                                src="{{asset('backend/assets/images/blog/placeholder.jpg')}}"
                                                id="output"
                                                width="100%"/>
                                        </p>
                                        <p id="remove-image" class="text-center" style="display: none;cursor: pointer"
                                           onclick="removeFeaturedImage(event)">Remove featured image</p>
                                    </div>

                                    <div class="post-title mt-5">
                                        <label for="title"><strong>Title*</strong></label>
                                        <input class="form-control" type="text" name="title" id="title"
                                               placeholder="Add Title"
                                               value="{{ old('title') }}">
                                    </div>
                                </div>
                            </div>

                            <div class="card mt-4">
                                <div class="card-header bg-white">Categories</div>
                                <div class="card-body">
                                    <div class="post-categories">
                                        @foreach($categories as $key => $category)
                                            <div class="form-check form-switch">
                                                <input class="form-check-input" type="checkbox"
                                                       id="categories-checkbox{{$key}}"
                                                       value="{{$category->id}}" name="category[]" @if(is_array(old('category')) && in_array($category->id, old('category'))) checked @endif>
                                                <label class="form-check-label text-capitalize"
                                                       for="categories-checkbox{{$key}}">{{$category->name}}</label>
                                            </div>
                                        @endforeach
                                    </div>
                                </div>
                            </div>

                            <div class="card mt-4">
                                <div class="card-body">
                                    <div class="headline-1">
                                        <label for="first-headline"><strong>Intro Heading*</strong></label>
                                        <input class="form-control" type="text" name="first_headline"
                                               id="first-headline"
                                               placeholder="Add Intro Heading" value="{{old('first_headline')}}">
                                    </div>
                                    <div class="first-description-box mt-2">
                                                <textarea class="form-control" name="first_description"
                                                          id="first-description" rows="4"
                                                          placeholder="Describe in details">{{old('first_description')}}</textarea>
                                    </div>

                                    <div class="headline-2 mt-3">
                                        <label for="last_headline"><strong>Outro Heading*</strong></label>
                                        <input type="text" class="form-control" id="last_headline"
                                               name="last_headline" placeholder="Add Outro Heading"
                                               value="{{old('last_headline')}}">
                                    </div>
                                    <div class="last-description-box mt-2">
                                            <textarea class="form-control" id="last-description" name="last_description"
                                                      placeholder="Describe in details" rows="4">{{old('last_description')}}</textarea>
                                    </div>
                                </div>
                            </div>

                            <div class="card mt-4">
                                <div class="card-header bg-white">Used Colors</div>
                                <div class="card-body color-body">
                                    <div>
                                        <input class="form-control form-control-sm" type="text" id="color_code"
                                               name="color_code[]" placeholder="#FFF000">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
            </div>
        </div>
        </form>
        <!-- Edit area ends  -->

        <!-- footer area start -->
        <footer>
            <div class="footer-content">
                <p>&copy; 2021 | Thornior | All right reserved</p>
                <p>V 1.8</p>
            </div>
        </footer>
        <!-- footer area ends  -->

    </div>
    <!-- content-right start -->

</div>


<!-- optional js -->
@include('layouts.all_scripts')
<script>
    // mobile menu responsive
    function menuAnimation(x) {
        x.classList.toggle("change");
        var element = document.getElementById("slideNav");
        element.classList.toggle("navSlide");
        var contentFade = document.getElementById("contentWidth");
        contentFade.classList.toggle("changeWidth");
    }

    // change content width
    function topNav(x) {
        x.classList.toggle("change");
        var element = document.getElementById("topList");
        element.classList.toggle("top-list");
    }
</script>
<script>
    var featuredImage = function (event) {
        // featured image
        // document.getElementById('image-box').style.display = 'block';
        var image = document.getElementById('output');
        image.src = URL.createObjectURL(event.target.files[0]);
        document.getElementById('image-label').style.display = 'none';
        document.getElementById('remove-image').style.display = 'block';
    };

    // remove image
    var removeFeaturedImage = function (event) {
        var imageInput = document.getElementById('file');
        imageInput.value = "";
        var image = document.getElementById('output');
        image.src = "{{asset('backend/assets/images/blog/placeholder.jpg')}}";

        // document.getElementById('image-box').style.display = 'none';
        document.getElementById('image-label').style.display = 'block';
        document.getElementById('remove-image').style.display = 'none';
    }

    // Last 3 images
    // 1st image
    var loadImage1 = function (event) {
        // document.getElementById('image-box1').style.display = 'block';
        var image1 = document.getElementById('output1');
        image1.src = URL.createObjectURL(event.target.files[0]);
        document.getElementById('image-label1').style.display = 'none';
        document.getElementById('remove-image1').style.display = 'block';
    };
    // remove image1
    var removeImage1 = function (event) {
        var imageInput1 = document.getElementById('file1');
        imageInput1.value = "";
        var image1 = document.getElementById('output1');
        image1.src = "{{asset('backend/assets/images/blog/placeholder.jpg')}}";

        // document.getElementById('image-box1').style.display = 'none';
        document.getElementById('image-label1').style.display = 'block';
        document.getElementById('remove-image1').style.display = 'none';
    }

    // 2nd images
    var loadImage2 = function (event) {
        // document.getElementById('image-box2').style.display = 'block';
        var image2 = document.getElementById('output2');
        image2.src = URL.createObjectURL(event.target.files[0]);
        document.getElementById('image-label2').style.display = 'none';
        document.getElementById('remove-image2').style.display = 'block';
    };
    // remove image2
    var removeImage2 = function (event) {
        var imageInput2 = document.getElementById('file2');
        imageInput2.value = "";
        var image2 = document.getElementById('output2');
        image2.src = "{{asset('backend/assets/images/blog/placeholder.jpg')}}";

        // document.getElementById('image-box2').style.display = 'none';
        document.getElementById('image-label2').style.display = 'block';
        document.getElementById('remove-image2').style.display = 'none';
    }

    // 3rd images
    var loadImage3 = function (event) {
        // document.getElementById('image-box3').style.display = 'block';
        var image3 = document.getElementById('output3');
        image3.src = URL.createObjectURL(event.target.files[0]);
        document.getElementById('image-label3').style.display = 'none';
        document.getElementById('remove-image3').style.display = 'block';
    };
    // remove image3
    var removeImage3 = function (event) {
        var imageInput3 = document.getElementById('file3');
        imageInput3.value = "";
        var image3 = document.getElementById('output3');
        image3.src = "{{asset('backend/assets/images/blog/placeholder.jpg')}}";

        // document.getElementById('image-box3').style.display = 'none';
        document.getElementById('image-label3').style.display = 'block';
        document.getElementById('remove-image3').style.display = 'none';
    }
</script>
<script>
    // JavaScript Form Validation
    function validateForm() {
        let fimage = document.forms["postForm"]["featured_image"].value;
        let image1 = document.forms["postForm"]["image1"].value;
        let image2 = document.forms["postForm"]["image2"].value;
        let image3 = document.forms["postForm"]["image3"].value;
        let editor = document.forms["postForm"]["editor"].value;
        if (fimage == "" || image1 == "" || image2 == "" || image3 == "" || editor == "") {
            alert("All field must be filled out");
            return false;
        }
    }
</script>

@include('layouts.add_colors')

<script>
    @if(Session::has('success'))
    var type = "{{Session::get('alert-type','success')}}"
    toastr.success("{{ Session::get('success') }}");
    @endif
</script>
<script>
    @if(Session::has('error'))
    var type = "{{Session::get('alert-type','error')}}"
    toastr.success("{{ Session::get('error') }}");
    @endif
</script>

@include('layouts.editorInit')
</body>
</html>
