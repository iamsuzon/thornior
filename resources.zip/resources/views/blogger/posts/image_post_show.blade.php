<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    @include('layouts.all_styles')

    <title>Thornior</title>
    <script src="{{asset('ckeditor5/build/ckeditor.js')}}"></script>
</head>
<body>
<style>
    .ck-editor__editable_inline {
        min-height: 1100px;
    }

    .word-count-card {
        padding: 10px 15px;
    }

    .word-count-card .ck-word-count__words {
        display: inline;
    }

    .word-count-card {
        padding: 0;
        border-radius: 0;
        border-top: 0;
    }

    .word-count-card-body .ck-word-count__characters {
        display: inline;
        margin-left: 10px;
    }

    .post-left-nav-button a:hover, .post-right-nav-button a:hover {
        background-color: #E2DED1;
    }
</style>

<div class="main-content">
    <!-- vertica sidebar start -->
    <div class="vertical-sidebar" id="slideNav">
        <div class="sidebar-content">
            <div class="brand-logo">
                <img src="{{asset('backend/assets/images/logo/01.png')}}" alt="">
                <span class="close-icon d-md-none float-end me-2" onclick="menuAnimation(this)">
                    <i class="fa fa-times"></i>
                </span>
            </div>
            <div class="seller-thumb">
                <div class="img-thumb">
                    <img src="{{asset('backend/assets/images/blogger/user.png')}}" alt="">
                </div>
                <div class="text-thumb">
                    <p>Natasa</p>
                    <span class="online-status">@natasa180</span>
                </div>
                <div class="post-status">
                    <ul class="status-list">
                        <li>
                            <strong>28</strong>
                            <p>Posts</p>
                        </li>
                        <li>
                            <strong>28</strong>
                            <p>Posts</p>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="sidebar-menu">
                <ul class="menu-list">
                    <div class="menu-title">
                        <p>Menu</p>
                    </div>
                    <li><a href="#0"><span><i class="fas fa-th-large"></i></span><span>Overview</span></a></li>
                    <li><a href="#0"><span><i class="fab fa-blogger-b"></i></span><span>Blog</span></a></li>
                    <li><a href="#0"><span><i class="fas fa-book-open"></i></span><span>Library</span></a></li>
                    <li class="accordion" id="accordionExample">
                        <a href="#0" class="headingOne" data-toggle="collapse" data-target="#collapseOne"
                           aria-expanded="false" aria-controls="collapseOne">
                            <span>
                                <i class="fas fa-hashtag"></i>
                            </span>
                            <span>Social Links</span>
                        </a>
                    </li>
                    <li><a href="#0"><span><i class="fas fa-cog"></i></span><span>Settings</span></a></li>
                    <div class="menu-title">
                        <p>Create</p>
                    </div>
                    <li><a class="active" href="#0"><span><i class="fas fa-paste"></i></span><span>Post</span></a></li>
                    <li><a href="#0"><span><i class="fas fa-list-ol"></i></span><span>Category</span></a></li>
                    <li><a href="#0"><span><i class="fas fa-gopuram"></i></span><span>Change Template</span></a></li>
                </ul>
            </div>

        </div>
    </div>
    <!-- vertica sidebar ends  -->


    <!-- content-right start -->
    <div class="content-right" id="contentWidth">

        <!-- top navbar start -->
    @include('layouts.logged_in_navbar')
    <!-- top navbar ends  -->


    <!-- post top navbar start -->
    @include('templates.image.v1')
    <!-- Edit area ends  -->

    </div>
    <!-- content-right start -->

</div>


<!-- optional js -->
@include('layouts.all_scripts')
<script>
    // mobile menu responsive
    function menuAnimation(x) {
        x.classList.toggle("change");
        var element = document.getElementById("slideNav");
        element.classList.toggle("navSlide");
        var contentFade = document.getElementById("contentWidth");
        contentFade.classList.toggle("changeWidth");
    }

    // change content width
    function topNav(x) {
        x.classList.toggle("change");
        var element = document.getElementById("topList");
        element.classList.toggle("top-list");
    }
</script>
<script>
    var featuredImage = function (event) {
        // featured image
        // document.getElementById('image-box').style.display = 'block';
        var image = document.getElementById('output');
        image.src = URL.createObjectURL(event.target.files[0]);
        document.getElementById('image-label').style.display = 'none';
        document.getElementById('remove-image').style.display = 'block';
    };

    // remove image
    var removeFeaturedImage = function (event) {
        var imageInput = document.getElementById('file');
        imageInput.value = "";
        var image = document.getElementById('output');
        image.src = "{{asset('backend/assets/images/blog/placeholder.jpg')}}";

        // document.getElementById('image-box').style.display = 'none';
        document.getElementById('image-label').style.display = 'block';
        document.getElementById('remove-image').style.display = 'none';
    }

    // Last 3 images
    // 1st image
    var loadImage1 = function (event) {
        // document.getElementById('image-box1').style.display = 'block';
        var image1 = document.getElementById('output1');
        image1.src = URL.createObjectURL(event.target.files[0]);
        document.getElementById('image-label1').style.display = 'none';
        document.getElementById('remove-image1').style.display = 'block';
    };
    // remove image1
    var removeImage1 = function (event) {
        var imageInput1 = document.getElementById('file1');
        imageInput1.value = "";
        var image1 = document.getElementById('output1');
        image1.src = "{{asset('backend/assets/images/blog/placeholder.jpg')}}";

        // document.getElementById('image-box1').style.display = 'none';
        document.getElementById('image-label1').style.display = 'block';
        document.getElementById('remove-image1').style.display = 'none';
    }

    // 2nd images
    var loadImage2 = function (event) {
        // document.getElementById('image-box2').style.display = 'block';
        var image2 = document.getElementById('output2');
        image2.src = URL.createObjectURL(event.target.files[0]);
        document.getElementById('image-label2').style.display = 'none';
        document.getElementById('remove-image2').style.display = 'block';
    };
    // remove image2
    var removeImage2 = function (event) {
        var imageInput2 = document.getElementById('file2');
        imageInput2.value = "";
        var image2 = document.getElementById('output2');
        image2.src = "{{asset('backend/assets/images/blog/placeholder.jpg')}}";

        // document.getElementById('image-box2').style.display = 'none';
        document.getElementById('image-label2').style.display = 'block';
        document.getElementById('remove-image2').style.display = 'none';
    }

    // 3rd images
    var loadImage3 = function (event) {
        // document.getElementById('image-box3').style.display = 'block';
        var image3 = document.getElementById('output3');
        image3.src = URL.createObjectURL(event.target.files[0]);
        document.getElementById('image-label3').style.display = 'none';
        document.getElementById('remove-image3').style.display = 'block';
    };
    // remove image3
    var removeImage3 = function (event) {
        var imageInput3 = document.getElementById('file3');
        imageInput3.value = "";
        var image3 = document.getElementById('output3');
        image3.src = "{{asset('backend/assets/images/blog/placeholder.jpg')}}";

        // document.getElementById('image-box3').style.display = 'none';
        document.getElementById('image-label3').style.display = 'block';
        document.getElementById('remove-image3').style.display = 'none';
    }
</script>

@include('layouts.add_colors')

<script>
    @if(Session::has('success'))
    var type = "{{Session::get('alert-type','success')}}"
    toastr.success("{{ Session::get('success') }}");
    @endif
</script>
<script>
    @if(Session::has('error'))
    var type = "{{Session::get('alert-type','error')}}"
    toastr.success("{{ Session::get('error') }}");
    @endif
</script>

@include('layouts.editorInit')
</body>
</html>
