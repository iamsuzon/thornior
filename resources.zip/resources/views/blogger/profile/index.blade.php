<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    @include('layouts.all_styles')

    <title>Thornior</title>
</head>
<body>


<div class="main-content">

    <!-- vertica sidebar start -->
    <div class="vertical-sidebar" id="slideNav">
        <div class="sidebar-content">
            <div class="brand-logo">
                <img src="{{asset('backend/assets/images/logo/01.png')}}" alt="">
                <span class="close-icon d-md-none float-end me-2" onclick="menuAnimation(this)">
                    <i class="fa fa-times"></i>
                </span>
            </div>
            <div class="seller-thumb">
                <div class="img-thumb">
                    <img src="{{asset('backend/assets/images/blogger/user.png')}}" alt="">
                </div>
                <div class="text-thumb">
                    <p>Natasa</p>
                    <span class="online-status">@natasa180</span>
                </div>
                <div class="post-status">
                    <ul class="status-list">
                        <li>
                            <strong>28</strong>
                            <p>Posts</p>
                        </li>
                        <li>
                            <strong>28</strong>
                            <p>Posts</p>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="sidebar-menu">
                <ul class="menu-list">
                    <div class="menu-title">
                        <p>Meny</p>
                    </div>
                    <li><a href="#0" class="active"><span><i class="fas fa-th-large"></i></span><span>Overview</span></a></li>
                    <li><a href="#0"><span><i class="fab fa-blogger-b"></i></span><span>Blog</span></a></li>
                    <li><a href="#0"><span><i class="fas fa-book-open"></i></span><span>Library</span></a></li>
                    <li class="accordion" id="accordionExample">
                        <a href="#0" class="headingOne" data-toggle="collapse" data-target="#collapseOne" aria-expanded="false" aria-controls="collapseOne">
                            <span>
                                <i class="fas fa-hashtag"></i>
                            </span>
                            <span>Social Links</span>
                        </a>
                    </li>
                    <li><a href="#0"><span><i class="fas fa-cog"></i></span><span>Settings</span></a></li>
                    <div class="menu-title">
                        <p>Create</p>
                    </div>
                    <li><a href="#0"><span><i class="fas fa-paste"></i></span><span>Post</span></a></li>
                    <li><a href="#0"><span><i class="fas fa-list-ol"></i></span><span>Category</span></a></li>
                    <li><a href="#0"><span><i class="fas fa-gopuram"></i></span><span>Change Template</span></a></li>
                </ul>
            </div>

        </div>
    </div>
    <!-- vertica sidebar ends  -->


    <!-- content-right start -->
    <div class="content-right" id="contentWidth">

        <!-- top navbar start -->
        <div class="top-navbar">
            <div class="container-fluid p-0">
                <div class="nav-item">
                    <div class="left-menu">
                        <div class="nav-toggle me-3" onclick="menuAnimation(this)">
                            <i class="fa fa-times"></i>
                        </div>
                        <ul class="left-menulist">
                            <li class="active">
                                <a href="#0">Blog</a>
                            </li>
                            <li>
                                <a href="#0">Explore</a>
                            </li>
                        </ul>
                    </div>
                    <div class="menu-item">
                        <ul class="item-list" id="topList">
                            <li><a href="#"><span><i class="fa fa-bell"></i></span></a></li>
                            <li class="dropdown">
                                <a href="#" class="dropdown-toggle" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false">
                                    <span><img src="{{asset('backend/assets/images/blogger/user.png')}}" height="35" width="35" alt=""></span>
                                    <span class="ml-1">Natasa</span>
                                </a>
                                <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
                                    <li><a class="dropdown-item" href="#">Action</a></li>
                                    <li><a class="dropdown-item" href="#">Another action</a></li>
                                    <li><a class="dropdown-item" href="#">Something else here</a></li>
                                </ul>
                            </li>
                        </ul>
                        <div class="top-toggle d-block d-sm-none" onclick="topNav(this)">
                            <i class="fa fa-ellipsis-v"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- top navbar ends  -->

        <!-- blogger area start -->
        <div class="blogger-area">
            <div class="container-fluid p-0">
                <div class="section-wrapper">
                    <!-- page header start -->
                    <section class="blogger-page-header">
                        <div class="header-content">
                            <span>Layout Name</span>
                            <h3>Blog</h3>
                            <span class="update">latest update</span>
                            <button type="button" class="btn"><span>Create Mode</span></button>
                        </div>
                    </section>
                    <!-- page header ends  -->

                    <!-- girid layout -->
                    <div class="row grid-row">
                        <div class="col-lg-9 col-12">
                            <!-- setup blog start -->
                            <section class="setup-blog">
                                <div class="section-header">
                                    <span>New</span>
                                    <h3>Set Up Your Blog</h3>
                                    <!-- slider arrow -->
                                    <div class="slider-arrow">
                                        <div class="latest-button-prev prev">
                                            <i class="fa fa-angle-left"></i>
                                        </div>
                                        <div class="latest-button-next next">
                                            <i class="fa fa-angle-right"></i>
                                        </div>
                                    </div>
                                </div>
                                <div class="section-wrapper">
                                    <div class="setup-slider">
                                        <div class="swiper-wrapper">
                                            <div class="swiper-slide">
                                                <div class="setup-item">
                                                    <div class="item-left">
                                                        <i class="fas fa-tools"></i>
                                                    </div>
                                                    <div class="item-right">
                                                        <h5>Create Mode</h5>
                                                        <span>Create Mode</span>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="swiper-slide">
                                                <div class="setup-item">
                                                    <div class="item-left">
                                                        <i class="fas fa-tools"></i>
                                                    </div>
                                                    <div class="item-right">
                                                        <h5>Create Mode</h5>
                                                        <span>Create Mode</span>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="swiper-slide">
                                                <div class="setup-item">
                                                    <div class="item-left">
                                                        <i class="fas fa-tools"></i>
                                                    </div>
                                                    <div class="item-right">
                                                        <h5>Create Mode</h5>
                                                        <span>Create Mode</span>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="swiper-slide">
                                                <div class="setup-item">
                                                    <div class="item-left">
                                                        <i class="fas fa-tools"></i>
                                                    </div>
                                                    <div class="item-right">
                                                        <h5>Create Mode</h5>
                                                        <span>Create Mode</span>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="swiper-slide">
                                                <div class="setup-item">
                                                    <div class="item-left">
                                                        <i class="fas fa-tools"></i>
                                                    </div>
                                                    <div class="item-right">
                                                        <h5>Create Mode</h5>
                                                        <span>Create Mode</span>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="swiper-slide">
                                                <div class="setup-item">
                                                    <div class="item-left">
                                                        <i class="fas fa-tools"></i>
                                                    </div>
                                                    <div class="item-right">
                                                        <h5>Create Mode</h5>
                                                        <span>Create Mode</span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </section>
                            <!-- setup blog ends  -->

                            <!-- blog library start -->
                            <section class="blog-libarary">
                                <div class="section-header">
                                    <h3>Library</h3>
                                </div>
                                <div class="section-wrapper">
                                    <div id="tabs">
                                        <ul class="mb-4">
                                            <li><a href="#tabs-1">Overview</a></li>
                                            <li><a href="#tabs-2">Post</a></li>
                                            <li><a href="#tabs-3">Category</a></li>
                                            <li><a href="#tabs-4">Videos</a></li>
                                        </ul>
                                        <div id="tabs-1">
                                            <div class="row">

                                                <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                                                    <div class="blog-item">
                                                        <div class="item-thumb">
                                                            <img src="assets/images/blog/latest/01.jpg" alt="">
                                                        </div>
                                                        <div class="item-content">
                                                            <div class="cato-content">
                                                                <span class="cat-btn">Diy</span>
                                                                <span><i class="fas fa-ellipsis-h"></i></span>
                                                            </div>
                                                            <p>7 Fun home projects to this summer</p>
                                                        </div>
                                                        <div class="hover-content">
                                                            <button type="button" class="btn"><span>Edit</span></button>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-lg-4 col-md-6 col-sm-6 col-12 mt-4 mt-sm-0">
                                                    <div class="blog-item">
                                                        <div class="item-thumb">
                                                            <img src="assets/images/blog/latest/01.jpg" alt="">
                                                        </div>
                                                        <div class="item-content">
                                                            <div class="cato-content">
                                                                <span class="cat-btn">Diy</span>
                                                                <span><i class="fas fa-ellipsis-h"></i></span>
                                                            </div>
                                                            <p>7 Fun home projects to this summer</p>
                                                        </div>
                                                        <div class="hover-content">
                                                            <button type="button" class="btn"><span>Edit</span></button>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-lg-4 col-md-6 col-sm-6 col-12 mt-4 mt-lg-0">
                                                    <div class="blog-item">
                                                        <div class="item-thumb">
                                                            <img src="assets/images/blog/latest/01.jpg" alt="">
                                                        </div>
                                                        <div class="item-content">
                                                            <div class="cato-content">
                                                                <span class="cat-btn">Diy</span>
                                                                <span><i class="fas fa-ellipsis-h"></i></span>
                                                            </div>
                                                            <p>7 Fun home projects to this summer</p>
                                                        </div>
                                                        <div class="hover-content">
                                                            <button type="button" class="btn"><span>Edit</span></button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div id="tabs-2">
                                            <p>Morbi tincidunt, dui sit amet facilisis feugiat, odio metus gravida ante, ut pharetra massa metus id nunc. Duis scelerisque molestie turpis. Sed fringilla, massa eget luctus malesuada, metus eros molestie lectus, ut tempus eros massa ut dolor. Aenean aliquet fringilla sem. Suspendisse sed ligula in ligula suscipit aliquam. Praesent in eros vestibulum mi adipiscing adipiscing. Morbi facilisis. Curabitur ornare consequat nunc. Aenean vel metus. Ut posuere viverra nulla. Aliquam erat volutpat. Pellentesque convallis. Maecenas feugiat, tellus pellentesque pretium posuere, felis lorem euismod felis, eu ornare leo nisi vel felis. Mauris consectetur tortor et purus.</p>
                                        </div>
                                        <div id="tabs-3">
                                            <p>Mauris eleifend est et turpis. Duis id erat. Suspendisse potenti. Aliquam vulputate, pede vel vehicula accumsan, mi neque rutrum erat, eu congue orci lorem eget lorem. Vestibulum non ante. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Fusce sodales. Quisque eu urna vel enim commodo pellentesque. Praesent eu risus hendrerit ligula tempus pretium. Curabitur lorem enim, pretium nec, feugiat nec, luctus a, lacus.</p>
                                            <p>Duis cursus. Maecenas ligula eros, blandit nec, pharetra at, semper at, magna. Nullam ac lacus. Nulla facilisi. Praesent viverra justo vitae neque. Praesent blandit adipiscing velit. Suspendisse potenti. Donec mattis, pede vel pharetra blandit, magna ligula faucibus eros, id euismod lacus dolor eget odio. Nam scelerisque. Donec non libero sed nulla mattis commodo. Ut sagittis. Donec nisi lectus, feugiat porttitor, tempor ac, tempor vitae, pede. Aenean vehicula velit eu tellus interdum rutrum. Maecenas commodo. Pellentesque nec elit. Fusce in lacus. Vivamus a libero vitae lectus hendrerit hendrerit.</p>
                                        </div>
                                        <div id="tabs-4">
                                            <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Tempore autem culpa sequi corporis ipsa iure provident aliquam accusamus amet ad tenetur temporibus quibusdam velit fugiat ratione laudantium consequatur fuga non omnis eius repellat quo, perspiciatis optio numquam! Tempora, maxime fugit.</p>
                                            <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Tempore autem culpa sequi corporis ipsa iure provident aliquam accusamus amet ad tenetur temporibus quibusdam velit fugiat ratione laudantium consequatur fuga non omnis eius repellat quo, perspiciatis optio numquam! Tempora, maxime fugit.</p>
                                        </div>
                                    </div>
                                </div>
                            </section>
                            <!-- blog library ends  -->
                        </div>
                        <div class="col-lg-3 col-md-7 col-sm-8 col-12">
                            <div class="blog-wizard">
                                <div class="wizard-title">
                                    <h4>Commets</h4>
                                    <a href="#0">See All</a>
                                </div>
                                <div class="wizard-body">
                                    <div class="blog-item border-bottom">
                                        <div class="blog-thumb">
                                            <img src="assets/images/blog/latest/02.jpg" alt="">
                                        </div>
                                        <div class="blog-text">
                                            <h5>Look into the exclusive dream house in the ...</h5>
                                        </div>
                                        <div class="blog-timeline">
                                            <div class="time-line">
                                                <span class="border-end pe-2">Mona Luna Litland</span>
                                                <span>5 Days ago</span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="comments-reply">
                                        <ul class="reply-list">
                                            <li>
                                                <div class="repl-thumb">
                                                    <img src="assets/images/blog/latest/01.png" alt="">
                                                </div>
                                                <div class="repl-text">
                                                    <h6>Logan</h6>
                                                    <p>Lorem ipsum dolor sit amet.</p>
                                                    <span><i class="fa fa-comment-alt"></i></span><span>Reply</span>
                                                </div>
                                            </li>
                                            <li>
                                                <div class="repl-thumb">
                                                    <img src="assets/images/blog/latest/01.png" alt="">
                                                </div>
                                                <div class="repl-text">
                                                    <h6>Jsica</h6>
                                                    <p>Lorem ipsum dolor sit amet.</p>
                                                    <span><i class="fa fa-comment-alt"></i></span><span>Reply</span>
                                                </div>
                                            </li>
                                            <li>
                                                <div class="repl-thumb">
                                                    <img src="assets/images/blog/latest/01.png" alt="">
                                                </div>
                                                <div class="repl-text">
                                                    <h6>Morgan</h6>
                                                    <p>Lorem ipsum dolor sit amet.</p>
                                                    <span><i class="fa fa-comment-alt"></i></span><span>Reply</span>
                                                </div>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="wizard-title mt-4">
                                    <h4>Latest Post</h4>
                                    <a href="#0">See All</a>
                                </div>
                                <div class="wizard-body">
                                    <ul class="blog-item">
                                        <li>
                                            <div class="blog-thumb">
                                                <img src="assets/images/blog/latest/01.jpg" alt="">
                                            </div>
                                            <div class="blog-text">
                                                <h6>Look in to the exclusive dream house...</h6>
                                                <div class="blog-timeline">
                                                    <div class="time-line">
                                                        <span class="border-end pe-2">Mona Luna Litland</span>
                                                        <span>5 Days ago</span>
                                                    </div>
                                                </div>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- girid layout -->
                </div>
            </div>
        </div>
        <!-- blogger area ends  -->

        <!-- footer area start -->
        @include('layouts.logged_in_footer')
        <!-- footer area ends  -->

    </div>
    <!-- content-right start -->

</div>


<!-- optional js -->
@include('layouts.all_scripts')

<script>
    // mobile menu responsive
    function menuAnimation(x) {
        x.classList.toggle("change");
        var element = document.getElementById("slideNav");
        element.classList.toggle("navSlide");
        var contentFade = document.getElementById("contentWidth");
        contentFade.classList.toggle("changeWidth");
    }

    // change content width
    function topNav(x) {
        x.classList.toggle("change");
        var element = document.getElementById("topList");
        element.classList.toggle("top-list");
    }
</script>

</body>
</html>
