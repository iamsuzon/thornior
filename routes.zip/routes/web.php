<?php

use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Artisan;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

/*
 | 1st. User Route
 | 2nd. Admin Route
 | 3rd. Blogger Route
 | 4th. Visitor Route
 */





//Route::get('/', function () {
//    return view('welcome');
//});

Route::get('/', [App\Http\Controllers\IndexController::class, 'index'])->name('index');

/* ---------------------------------------------------------------------------------------------- */
/* User Login , Registration , Password Reset */
Auth::routes();

/* User Email Verification */
Route::prefix('user')->group(function(){
    Route::get('/email/verify', [App\Http\Controllers\Auth\UserEmailVerificationController::class, 'mustVerify'])->middleware('auth')->name('verification.notice');
    Route::get('/email/verify/{id}/{hash}', [App\Http\Controllers\Auth\UserEmailVerificationController::class, 'emailVerified'])->middleware(['auth', 'signed'])->name('verification.verify');
    Route::post('/email/verification-notification', [App\Http\Controllers\Auth\UserEmailVerificationController::class, 'sendVerifyEmail'])->middleware(['auth', 'throttle:6,1'])->name('verification.send');
});

/* User Dashboard */
Route::prefix('user')->middleware(['auth:web','verified'])->group(function(){
    /* If User Not Approved */
    Route::get('/approve', [App\Http\Controllers\Auth\UserEmailVerificationController::class, 'userNotApprove'])->name('user.notapprove');

    /* Approving User */
    Route::middleware('isapproved')->group(function(){
        Route::get('/dashboard', [App\Http\Controllers\UserControllers\UserController::class, 'index'])->name('user.dashboard');
    });
});
/* ---------------------------------------------------------------------------------------------- */





/* ---------------------------------------------------------------------------------------------- */
/* Admin Login */
Route::get('/admin-login', [App\Http\Controllers\Auth\AdminLoginController::class, 'showForm'])->name('admin.login.show');
Route::post('/admin-login', [App\Http\Controllers\Auth\AdminLoginController::class, 'login'])->name('admin.login.submit');

/* Admin Password Reset */
Route::prefix('admin')->group(function(){
    Route::get('/password/reset',[App\Http\Controllers\Auth\AdminForgotPasswordController::class, 'showLinkRequestForm'])->name('admin.password.request');
    Route::post('/password/email',[App\Http\Controllers\Auth\AdminForgotPasswordController::class, 'sendResetLinkEmail'])->name('admin.password.email');
    Route::post('/password/reset',[App\Http\Controllers\Auth\AdminResetPasswordController::class, 'reset'])->name('admin.password.update');
    Route::get('/password/reset/{token}',[App\Http\Controllers\Auth\AdminResetPasswordController::class, 'showResetForm'])->name('admin.password.reset');
});

/* Admin Dashboard */
Route::prefix('admin')->namespace('AdminControllers')->middleware('auth:admin')->group(function(){
    Route::get('/', function (){return redirect(route('admin.dashboard'));});
    Route::get('/dashboard', [App\Http\Controllers\AdminControllers\AdminController::class, 'index'])->name('admin.dashboard');

    /* Category Management */
    Route::get('/category', [App\Http\Controllers\AdminControllers\CategoryController::class, 'index'])->name('admin.category.index');
    Route::post('/category', [App\Http\Controllers\AdminControllers\CategoryController::class, 'store'])->name('admin.category.store');
    Route::post('/category/edit/{id}', [App\Http\Controllers\AdminControllers\CategoryController::class, 'edit'])->name('admin.category.edit');
    Route::get('/category/delete/{id}', [App\Http\Controllers\AdminControllers\CategoryController::class, 'delete'])->name('admin.category.delete');

    /* Admin Settings */
    Route::get('/settings/profile', [App\Http\Controllers\AdminControllers\AdminController::class, 'profile'])->name('admin.settings.profile.index');
    Route::get('/settings/profile/edit/{id}', function (){
        return redirect(route('admin.settings.profile.index'));
    });
    Route::post('/settings/profile/edit/{id}', [App\Http\Controllers\AdminControllers\AdminController::class, 'editProfile'])->name('admin.settings.profile.edit');

    /* Logout */
    Route::post('/admin-logout', [App\Http\Controllers\Auth\AdminLoginController::class, 'adminlogout'])->name('admin.logout');

    /* Blogger Management */
    Route::get('/blogger', [App\Http\Controllers\AdminControllers\CreateBloggerController::class, 'index'])->name('admin.blogger.index');
    Route::get('/blogger/create', [App\Http\Controllers\AdminControllers\CreateBloggerController::class, 'create'])->name('admin.blogger.create');
    Route::post('/blogger/create', [App\Http\Controllers\AdminControllers\CreateBloggerController::class, 'sent'])->name('admin.blogger.sent');
    Route::get('/blogger/create/again/{email}', [App\Http\Controllers\AdminControllers\CreateBloggerController::class, 'sentagain'])->name('admin.blogger.sent.again');
    Route::get('/blogger/{id}', [App\Http\Controllers\AdminControllers\CreateBloggerController::class, 'giveapproval'])->name('admin.blogger.account.giveapproval');

    Route::get('down', function (){
        Artisan::call('down');
    });
});

Route::get('/blogger/account/{token}', [App\Http\Controllers\AdminControllers\CreateBloggerController::class, 'compare'])->name('admin.blogger.account.compare')->middleware('checkinvitetoken');
Route::post('/blogger/account/create', [App\Http\Controllers\AdminControllers\CreateBloggerController::class, 'store'])->name('admin.blogger.account.store');

Route::get('/blogger/account/approval/{id}', [App\Http\Controllers\AdminControllers\CreateBloggerController::class, 'waitapproval'])->name('admin.blogger.account.approval');
/* ---------------------------------------------------------------------------------------------- */





/* ---------------------------------------------------------------------------------------------- */
/* Blogger Login */
Route::get('/blogger-login', [App\Http\Controllers\Auth\BloggerLoginController::class, 'showForm'])->name('blogger.login.show');
Route::post('/blogger-login', [App\Http\Controllers\Auth\BloggerLoginController::class, 'login'])->name('blogger.login.submit');

/* Blogger Password Reset */
Route::prefix('blogger')->group(function(){
    Route::get('/password/reset',[App\Http\Controllers\Auth\AdminForgotPasswordController::class, 'showLinkRequestForm'])->name('blogger.password.request');
    Route::post('/password/email',[App\Http\Controllers\Auth\AdminForgotPasswordController::class, 'sendResetLinkEmail'])->name('blogger.password.email');
    Route::post('/password/reset',[App\Http\Controllers\Auth\AdminResetPasswordController::class, 'reset'])->name('blogger.password.update');
    Route::get('/password/reset/{token}',[App\Http\Controllers\Auth\AdminResetPasswordController::class, 'showResetForm'])->name('blogger.password.reset');
});

/* Blogger Dashboard */
Route::prefix('blogger')->middleware(['auth:blogger'])->group(function(){
    Route::get('/', function (){
       return redirect()->route('blogger.dashboard');
    });

    /* If Blogger Not Approved */
    Route::get('/approve', [App\Http\Controllers\Auth\UserEmailVerificationController::class, 'notApprove'])->name('blogger.notapprove');

    Route::middleware('isapproved')->group(function(){

        /* Blog Creation Process */
        Route::middleware('hasblog_nosetup')->group(function (){
            Route::match(['get','post'],'setup/blog/step-1', [App\Http\Controllers\BloggerControllers\BlogCreationController::class, 'step1'])->name('blogger.blog.create.step1');
            Route::match(['get','post'],'setup/blog/step-2', [App\Http\Controllers\BloggerControllers\BlogCreationController::class, 'step2'])->name('blogger.blog.create.step2');
            Route::match(['get','post'],'setup/blog/step-3', [App\Http\Controllers\BloggerControllers\BlogCreationController::class, 'step3'])->name('blogger.blog.create.step3');
            Route::match(['get','post'],'setup/blog/step-4', [App\Http\Controllers\BloggerControllers\BlogCreationController::class, 'step4'])->name('blogger.blog.create.step4');
            Route::match(['get','post'],'setup/blog/final', [App\Http\Controllers\BloggerControllers\BlogCreationController::class, 'final'])->name('blogger.blog.create.final');
        });

        /* Dashboard */
        Route::middleware('hasblog')->group(function(){
            Route::get('/dashboard', [App\Http\Controllers\BloggerControllers\BloggerController::class, 'index'])->name('blogger.dashboard');

            /* Post */
            Route::get('/blog/post/templates', [App\Http\Controllers\BloggerControllers\PostTemplateController::class, 'postTemplates'])->name('blogger.blog.post.templates');

            /* Post - Image Post One */
            Route::get('/blog/post/image/template1', [App\Http\Controllers\BloggerControllers\ImagePostController::class, 'ImagePostIndexOne'])->name('blogger.blog.post.image.index.1');
            Route::post('/blog/post/image/template1/store', [App\Http\Controllers\BloggerControllers\ImagePostController::class, 'ImagePostStoreOne'])->name('blogger.blog.post.image.store.1');
            Route::get('/blog/post/image/template1/show/{slug}', [App\Http\Controllers\BloggerControllers\ImagePostController::class, 'ImagePostShowOne'])->name('blogger.blog.post.image.show');
            Route::get('/blog/post/image/template1/edit/{id}', [App\Http\Controllers\BloggerControllers\ImagePostController::class, 'ImagePostEditOne'])->name('blogger.blog.post.image.edit.1');
            Route::post('/blog/post/image/template1/edit/{id}', [App\Http\Controllers\BloggerControllers\ImagePostController::class, 'ImagePostUpdateOne'])->name('blogger.blog.post.image.update.1');

            /* Post - Video Post */
            Route::get('/blog/post/video', [App\Http\Controllers\BloggerControllers\VideoPostController::class, 'VideoPostIndex'])->name('blogger.blog.post.video.index');
//            Route::post('/blog/post/image/store', [App\Http\Controllers\BloggerControllers\ImagePostController::class, 'ImagePostStore'])->name('blogger.blog.post.image.store');
//            Route::get('/blog/post/image/show/{slug}', [App\Http\Controllers\BloggerControllers\ImagePostController::class, 'ImagePostShow'])->name('blogger.blog.post.image.show');
//            Route::get('/blog/post/image/edit/{id}', [App\Http\Controllers\BloggerControllers\ImagePostController::class, 'ImagePostEdit'])->name('blogger.blog.post.image.edit');
//            Route::post('/blog/post/image/edit/{id}', [App\Http\Controllers\BloggerControllers\ImagePostController::class, 'ImagePostUpdate'])->name('blogger.blog.post.image.update');

            /* Products */
            Route::get('/blog/post/image/products', [App\Http\Controllers\BloggerControllers\BloggerProductController::class, 'getAllProducts'])->name('blogger.blog.post.image.products');

            Route::get('/blog/product', [App\Http\Controllers\BloggerControllers\BloggerProductController::class, 'index'])->name('blogger.blog.product.index');
            Route::post('/blog/product', [App\Http\Controllers\BloggerControllers\BloggerProductController::class, 'store'])->name('blogger.blog.product.store');
            Route::get('/blog/product/update', function () {return back();});
            Route::post('/blog/product/update', [App\Http\Controllers\BloggerControllers\BloggerProductController::class, 'update'])->name('blogger.blog.product.update');
            Route::get('/blog/product/draft/{post_id}', [App\Http\Controllers\BloggerControllers\BloggerProductController::class, 'draft'])->name('blogger.blog.product.draft');
            Route::get('/blog/product/undraft/{post_id}', [App\Http\Controllers\BloggerControllers\BloggerProductController::class, 'undraft'])->name('blogger.blog.product.undraft');
            Route::get('/blog/product/delete/{post_id}', [App\Http\Controllers\BloggerControllers\BloggerProductController::class, 'delete'])->name('blogger.blog.product.delete');

            /* Profile */
            Route::get('/profile', [App\Http\Controllers\BloggerControllers\BloggerController::class, 'profile'])->name('blogger.profile');

            /* Settings */
            Route::get('/settings', function (){
                return redirect()->route('blogger.settings.profile');
            });
            Route::get('/settings/profile', [App\Http\Controllers\BloggerControllers\BloggerController::class, 'settingsProfileShow'])->name('blogger.settings.profile');
            Route::post('/settings/profile', [App\Http\Controllers\BloggerControllers\BloggerController::class, 'settingsProfileSubmit'])->name('blogger.settings.profile.submit');
            Route::post('/settings/profile/image', [App\Http\Controllers\BloggerControllers\BloggerController::class, 'settingsProfileImageSubmit'])->name('blogger.settings.profile.image.submit');
        });
    });

    /* Logout */
    Route::get('/blogger-logout', [App\Http\Controllers\Auth\BloggerLoginController::class, 'bloggerlogout'])->name('blogger.logout');
});
/* ---------------------------------------------------------------------------------------------- */




/* ---------------------------------------------------------------------------------------------- */
/* Visitor */
/* All Post */
Route::get('all-posts', [App\Http\Controllers\VisitorController::class, 'index'])->name('visitor.post.all');
Route::get('posts/{id}', [App\Http\Controllers\VisitorController::class, 'show'])->name('visitor.post.show');

/* ---------------------------------------------------------------------------------------------- */
